Documentación Shop Cart – Tienda Online

Git: https://github.com/alotav/React_Store_App
Vercel: https://react-store-app-beta.vercel.app/

La aplicación consume una fake api y muestra los productos que entrega a modo de tienda online.
Esta dividida en 4 secciones en las que podemos navegar por medio del componente Header:

Productos: lista el total de productos de la API, cada uno de ellos en un componente Card. Podemos agregar los productos al carrito por medio del botón Comprar.

Sale: lista los productos que tienen precio menor a $15. Al igual que en la sección de productos, podemos agregar los elementos al carrito por medio del botón comprar del componente Card.

Quienes Somos: hacemos una breve explicación sobre el proyecto.

Carrito: es el componente que mantiene toda la lógica de negocio. Podremos ver montos, precio final, hacer vaciado del carrito de compras y un pago ficticio como finalización del proceso de compras.

CartCard: dentro del carrito podremos ver la lista de productos agregados, cada uno en una card que podremos ver dentro del código como “CartCard”. Este componente permite modificar las cantidades del producto agregado en el carrito.

Botón Vaciar Carrito: vacía el contenido del carrito.

Botón Finalizar Compra: lleva a la sección de pago donde se realizara el pago ficticio de la compra. Se trata de un formulario que hace una validación simple de los datos ingresados por el usuario, teniendo en cuenta los siguientes requisitos para cada campo:

- Numero de la tarjeta: valida que el valor ingresado sea numérico y que al menos tenga 16 caracteres.
- Nombre del titular: valida que se ingrese un valor de tipo texto que debe cunplir con una longitud mínima de 8 caracteres, debiendo contener un espacio vacio (que no puede ser el carácter de inicio de la cadena).
- Día: el día debe comprender valores entre 1 y 31.
- Mes: el mes debe comprender valores entre 1 y 12.
- Codito CVC: el valor del código no puede ser mayor a 3 dígitos y su valor va desde 000 a 999.

Una vez se cumpla con las validaciones podremos finalizar la compra desde el botón “Realizar pago”.