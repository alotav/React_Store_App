# Trabajo Integrador (Shop Cart)

## Instalar

...
npm install
npm install react-router-dom
...

## Ejecutar

...
npm run dev
...

## Enlaces
[GitHub](https://github.com/alotav/React_Store_App)
[Vercel](https://react-store-app-beta.vercel.app/)